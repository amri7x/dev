# skill-maintenance

Skill reusable untuk mengevaluasi dan meningkatkan agent-skill berdasarkan pengalaman penggunaan dan bukti yang tersedia.

## Instalasi

Salin direktori `skill-maintenance/` ke direktori skill yang didukung oleh coding agent. Pertahankan `SKILL.md` dan direktori `references/` dalam satu paket.

## Penggunaan

```text
/skill-maintenance
/skill-maintenance path/ke/SKILL.md
/skill-maintenance --audit
```

Skill ini mengusulkan perubahan terlebih dahulu dan meminta persetujuan sebelum mengedit. Jika tidak tersedia riwayat penggunaan, skill hanya melakukan evaluasi berdasarkan file dan bukti yang bisa diakses.

## Prinsip penting

Skill tidak berkembang otomatis hanya karena sering dipakai. Perbaikan permanen memerlukan pembaruan instruksi atau referensi yang ditinjau dan disetujui.

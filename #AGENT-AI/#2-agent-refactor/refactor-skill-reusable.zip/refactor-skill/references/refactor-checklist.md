# Refactor Checklist

Use this checklist for every `/refactor-skill` invocation.

## Before editing
- [ ] Confirm repository root and inspect current working-tree changes.
- [ ] Resolve all target paths; confirm each is an intended file.
- [ ] Treat only user-specified targets as writable.
- [ ] Read relevant repository instructions and representative style examples.
- [ ] Identify concrete style mismatches and plan the smallest useful refactor.

## While editing
- [ ] Keep reference files and all non-target files read-only.
- [ ] Preserve behavior, public contracts, security checks, and error semantics.
- [ ] Avoid unrelated cleanup, feature work, and cosmetic churn.
- [ ] Do not use write-mode tools that can alter files outside the target list.

## After editing
- [ ] Inspect the full diff.
- [ ] Confirm changed paths are a subset of the target list.
- [ ] Review logic-sensitive areas: conditions, validation, authorization, errors, side effects, transactions, and cleanup.
- [ ] Run appropriate non-invasive checks when practical.
- [ ] Re-check working-tree status.
- [ ] Report actual checks and limitations without overstating confidence.

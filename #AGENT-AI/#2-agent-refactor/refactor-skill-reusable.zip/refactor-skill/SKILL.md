---
name: refactor-skill
description: Refactor one or more explicitly specified files to match the active repository's established coding style while preserving behavior and strictly limiting edits to the requested files. Use when asked to standardize, clean up, or restyle code without broad redesign.
---

# Refactor Skill

Refactor the file paths explicitly provided by the user so their code follows the established conventions of the **currently active repository**. This skill is reusable across repositories, languages, frameworks, and project structures.

## Core principles

1. **Learn from the repository; do not assume a house style.** Inspect real, representative source files before editing.
2. **Keep the scope strict.** Only edit files explicitly named by the user for this invocation. Reference files and all other files are read-only.
3. **Preserve behavior.** This is a refactor, not a feature change, bug fix, redesign, or architecture migration.
4. **Make the smallest useful change.** Prefer local, focused edits over broad rewrites.
5. **Verify honestly.** Run relevant checks when practical and report exactly what was and was not verified.

## Invocation

Expected usage:

- `/refactor-skill path/to/file`
- `/refactor-skill path/to/file-a path/to/file-b`
- `/refactor-skill path/to/file --style-reference path/to/reference`
- `/refactor-skill path/to/file --style-references path/to/reference-a path/to/reference-b`

Treat paths named as targets as the only files permitted to change. A reference option adds read-only style examples; it does not authorize editing those files. If the invocation format is ambiguous, ask one concise question before editing.

If the user's environment uses a skill name as the invocation command, expose this skill as `/refactor-skill`; do not silently rename it.

## Workflow

### 1. Establish the working repository and targets

- Confirm the active repository root and inspect the working tree status.
- Resolve each requested target path relative to the repository unless the user clearly specifies an absolute path.
- Confirm each target exists and is a file. If a target is missing, ambiguous, outside the active repository, or is a symlink whose destination escapes the repository, stop and ask for clarification rather than guessing.
- Record the initial diff/status so pre-existing user changes are not mistaken for your own.
- Do not overwrite, revert, stash, or otherwise disturb existing user changes.
- Do not expand the target list automatically, even if related files appear to need changes.

### 2. Discover the house style

Use the following order of preference:

1. Explicit style-reference paths supplied by the user.
2. Nearby files in the same module or feature that serve the same role.
3. Established examples elsewhere in the repository with the same language, framework, and layer.
4. Repository-level instructions and configuration, such as `AGENTS.md`, formatter/linter configuration, language conventions, and contribution guides.

Inspect only enough files to identify the conventions relevant to the target. Prefer multiple representative examples when available. Consider:

- Naming and file/module organization
- Imports and dependency direction
- Formatting, whitespace, line length, and quote style
- Function/class size and decomposition
- Error handling and validation
- Logging and comments
- Types, interfaces, and return conventions
- Async patterns, resource cleanup, and control flow
- Tests and mocking conventions, where relevant

Do not assume that one example represents the whole codebase if examples conflict. Prefer the closest equivalent in the same layer and follow the repository's documented rules. If the style is genuinely ambiguous and the choice materially affects the result, ask the user before proceeding.

If no reliable house style can be established, explain the uncertainty and either ask for a reference or make only uncontroversial, low-risk consistency changes.

### 3. Define the permitted change set

Before editing, list the exact target paths internally and keep them fixed for the task.

- Only those paths may be modified.
- Style references, configuration, tests, lockfiles, generated files, and documentation are read-only unless explicitly included as targets.
- Do not run commands that automatically rewrite files outside the target set, including repository-wide formatters, codemods, autofixes, or generators.
- A check may create temporary artifacts; avoid persistent side effects outside targets where possible and clean up only artifacts created by this run.
- If a required verification step would modify an out-of-scope file, do not run it in write mode. Prefer a read-only or check-only mode.

### 4. Plan the refactor

Identify concrete mismatches between each target and the learned style. Make a short plan focused on style and maintainability, for example:

- Normalize naming or structure to match nearby equivalents.
- Simplify unnecessarily complex control flow without changing outcomes.
- Align error handling and validation patterns with the established code.
- Remove duplication only when the extraction is local, clear, and behavior-preserving.
- Adjust comments and types only when they improve consistency and remain accurate.

Do not add features, alter public interfaces, change business rules, modify data formats, change security behavior, or introduce new dependencies unless the user explicitly asks for those changes. If a requested style change appears to require a behavioral change, stop and ask.

### 5. Edit narrowly

- Edit only the explicitly named target files.
- Preserve existing unrelated user edits and avoid reformatting unrelated sections.
- Keep public APIs, exported symbols, function signatures, observable side effects, error semantics, and compatibility unchanged unless explicitly authorized.
- Preserve security checks, authorization rules, validation, transaction boundaries, and resource cleanup.
- Do not suppress tests, weaken lint rules, or alter configuration to make the refactor pass.
- Avoid cosmetic churn that makes review harder than the improvement warrants.

### 6. Verify the result

Use the least invasive checks available:

1. Inspect the diff and confirm every changed path is in the target list.
2. Review the diff for accidental logic changes, removed guards, altered conditions, changed error handling, and unrelated formatting.
3. Run relevant read-only checks or targeted tests if practical.
4. If tests or formatters may write files, confirm they cannot alter out-of-scope files before running them.
5. Re-check repository status after verification.

If a verification command fails, distinguish failures caused by the refactor from pre-existing or environment-related failures. Never claim a test, lint, type check, or build passed unless it actually ran successfully.

If a necessary fix would require editing an unlisted file, do not make that change. Report the issue and ask the user to add that file to the target list if they want it changed.

### 7. Report

Summarize:

- Which target files were changed.
- The main style conventions applied.
- Whether behavior was intended to remain unchanged.
- Checks run and their actual outcomes.
- Any unresolved ambiguity, risk, or follow-up requiring additional target files.

Be concise. Do not claim full behavioral equivalence solely because tests pass.

## Stop and ask before editing when

- The target file cannot be resolved confidently.
- The target is outside the active repository or resolves outside it through a symlink.
- There is no reliable style reference and the expected style cannot be inferred safely.
- The user requests mutually conflicting style rules.
- The requested refactor would require changes to non-target files.
- A change that appears stylistic would alter runtime behavior or a public contract.

## Reference material

For a compact execution checklist, consult `references/refactor-checklist.md`.

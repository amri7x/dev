# refactor-skill

Reusable skill for refactoring explicitly specified files to match the coding conventions of the active repository.

## Install

Copy the `refactor-skill/` directory into the skills directory supported by your coding agent. Keep `SKILL.md` and the `references/` directory together.

## Use

```text
/refactor-skill path/to/file.ts
/refactor-skill path/to/first.ts path/to/second.ts
/refactor-skill path/to/file.ts --style-reference path/to/example.ts
```

The skill discovers conventions dynamically from the active repository. It does not hard-code project-specific folders.

## Safety contract

Only files explicitly supplied as targets may be modified. Style references, configs, tests, docs, lockfiles, and other files remain read-only unless separately included as targets. The refactor should preserve runtime behavior and public contracts.

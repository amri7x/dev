# Daftar Periksa Refactor

Gunakan daftar periksa ini setiap kali menjalankan `/refactor-skill`.

## Sebelum mengedit
- [ ] Pastikan root repositori dan periksa perubahan working tree yang sudah ada.
- [ ] Resolusi semua path target dan pastikan setiap target adalah file yang dimaksud.
- [ ] Hanya file target yang disebutkan pengguna yang boleh ditulis.
- [ ] Baca instruksi repositori dan contoh gaya yang relevan.
- [ ] Identifikasi perbedaan gaya yang konkret dan rencanakan perubahan sekecil mungkin.

## Saat mengedit
- [ ] Jangan mengubah file referensi maupun file lain di luar target.
- [ ] Pertahankan perilaku, kontrak publik, pemeriksaan keamanan, dan semantik error.
- [ ] Hindari pekerjaan tambahan yang tidak terkait, penambahan fitur, dan perubahan kosmetik berlebihan.
- [ ] Jangan gunakan alat/perintah dalam mode tulis yang dapat mengubah file di luar daftar target.

## Setelah mengedit
- [ ] Periksa seluruh diff.
- [ ] Pastikan semua path yang berubah termasuk dalam daftar target.
- [ ] Tinjau bagian yang sensitif terhadap logika: kondisi, validasi, otorisasi, error, efek samping, transaksi, dan pembersihan resource.
- [ ] Jalankan pemeriksaan yang sesuai dan minim dampak jika memungkinkan.
- [ ] Periksa kembali status working tree.
- [ ] Laporkan pemeriksaan dan keterbatasan yang sebenarnya tanpa melebih-lebihkan tingkat kepastian.
